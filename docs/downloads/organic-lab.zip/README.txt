SIMULATED ORGANIC-LAB PRACTICE FILES
No prior chemistry is needed. This exercise searches supplied labels
and inspects numerical records; no laboratory procedure is required.
inventory.tsv has one header and four sample records. O01 is labelled
alcohol, O02/O03 ester, O04 carboxylic-acid. These labels are given.
The recovery CSV describes twelve independent synthesis runs, six
per randomly assigned collection protocol. Read DICTIONARY.txt.
