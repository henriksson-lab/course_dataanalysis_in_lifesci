SIMULATED LAB-GROUP DATA
Four independent seedling pots, two control and two nutrient-treated.
Each measurement file has one observation of length after seven days.
Lengths are millimetres. samples.tsv lists sample IDs and file locations.
The field-notes folder contains short observations; it is plain text.
